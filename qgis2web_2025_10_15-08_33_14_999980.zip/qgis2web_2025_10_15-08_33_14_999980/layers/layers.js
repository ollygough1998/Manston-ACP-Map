var wms_layers = [];


        var lyr_ESRIGraylight_0 = new ol.layer.Tile({
            'title': 'ESRI Gray (light)',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://services.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}'
            })
        });

        var lyr_Openstreetmaptracks_1 = new ol.layer.Tile({
            'title': 'Openstreetmap tracks',
            'opacity': 0.247000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://gps-a.tile.openstreetmap.org/lines/{z}/{x}/{y}.png'
            })
        });

        var lyr_OSMStandard_2 = new ol.layer.Tile({
            'title': 'OSM Standard',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '&nbsp;&middot; <a href="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors, CC-BY-SA</a>',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });

        var lyr_GoogleSatellite_3 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '&nbsp;&middot; <a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });

        var lyr_maptiler_4 = new ol.layer.Tile({
            'title': 'maptiler',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://api.maptiler.com/maps/streets-v4/256/tiles.json?key=tNBidVRf6tKLYVchECo3'
            })
        });
var format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5 = new ol.format.GeoJSON();
var features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5 = format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5.readFeatures(json_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5.addFeatures(features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5);
var lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5, 
                style: style_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5,
                popuplayertitle: 'ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 60dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5.png" /> ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 60dB.shp'
            });
var format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6 = new ol.format.GeoJSON();
var features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6 = format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6.readFeatures(json_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6.addFeatures(features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6);
var lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6, 
                style: style_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6,
                popuplayertitle: 'ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 57dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6.png" /> ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 57dB.shp'
            });
var format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7 = new ol.format.GeoJSON();
var features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7 = format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7.readFeatures(json_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7.addFeatures(features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7);
var lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7, 
                style: style_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7,
                popuplayertitle: 'ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 54dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7.png" /> ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 54dB.shp'
            });
var format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8 = new ol.format.GeoJSON();
var features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8 = format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8.readFeatures(json_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8.addFeatures(features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8);
var lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8, 
                style: style_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8,
                popuplayertitle: 'ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 69dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8.png" /> ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 69dB.shp'
            });
var format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9 = new ol.format.GeoJSON();
var features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9 = format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9.readFeatures(json_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9.addFeatures(features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9);
var lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9, 
                style: style_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9,
                popuplayertitle: 'ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 51dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9.png" /> ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 51dB.shp'
            });
var format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10 = new ol.format.GeoJSON();
var features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10 = format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10.readFeatures(json_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10.addFeatures(features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10);
var lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10, 
                style: style_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10,
                popuplayertitle: 'ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 66dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10.png" /> ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 66dB.shp'
            });
var format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11 = new ol.format.GeoJSON();
var features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11 = format_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11.readFeatures(json_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11.addFeatures(features_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11);
var lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11, 
                style: style_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11,
                popuplayertitle: 'ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 63dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11.png" /> ACP-C3-1_Day_2038_LAeq — ACP-C3-1 Day 2038 LAeq 63dB.shp'
            });
var format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12 = new ol.format.GeoJSON();
var features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12 = format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12.readFeatures(json_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12.addFeatures(features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12);
var lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12, 
                style: style_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12,
                popuplayertitle: 'ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 51dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12.png" /> ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 51dB.shp'
            });
var format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13 = new ol.format.GeoJSON();
var features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13 = format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13.readFeatures(json_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13.addFeatures(features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13);
var lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13, 
                style: style_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13,
                popuplayertitle: 'ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 54dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13.png" /> ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 54dB.shp'
            });
var format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14 = new ol.format.GeoJSON();
var features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14 = format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14.readFeatures(json_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14.addFeatures(features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14);
var lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14, 
                style: style_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14,
                popuplayertitle: 'ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 57dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14.png" /> ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 57dB.shp'
            });
var format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15 = new ol.format.GeoJSON();
var features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15 = format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15.readFeatures(json_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15.addFeatures(features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15);
var lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15, 
                style: style_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15,
                popuplayertitle: 'ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 60dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15.png" /> ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 60dB.shp'
            });
var format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16 = new ol.format.GeoJSON();
var features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16 = format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16.readFeatures(json_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16.addFeatures(features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16);
var lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16, 
                style: style_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16,
                popuplayertitle: 'ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 63dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16.png" /> ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 63dB.shp'
            });
var format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17 = new ol.format.GeoJSON();
var features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17 = format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17.readFeatures(json_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17.addFeatures(features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17);
var lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17, 
                style: style_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17,
                popuplayertitle: 'ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 66dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17.png" /> ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 66dB.shp'
            });
var format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18 = new ol.format.GeoJSON();
var features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18 = format_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18.readFeatures(json_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18.addFeatures(features_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18);
var lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18, 
                style: style_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18,
                popuplayertitle: 'ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 69dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18.png" /> ACP-C3-1_Day_2029_LAeq — ACP-C3-1 Day 2029 LAeq 69dB.shp'
            });
var format_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19 = format_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19.readFeatures(json_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19.addFeatures(features_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19);
var lyr_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19, 
                style: style_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 57dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19.png" /> ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 57dB.shp'
            });
var format_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20 = format_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20.readFeatures(json_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20.addFeatures(features_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20);
var lyr_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20, 
                style: style_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 51dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20.png" /> ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 51dB.shp'
            });
var format_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21 = format_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21.readFeatures(json_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21.addFeatures(features_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21);
var lyr_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21, 
                style: style_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 54dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21.png" /> ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 54dB.shp'
            });
var format_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22 = format_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22.readFeatures(json_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22.addFeatures(features_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22);
var lyr_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22, 
                style: style_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 60dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22.png" /> ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 60dB.shp'
            });
var format_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23 = format_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23.readFeatures(json_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23.addFeatures(features_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23);
var lyr_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23, 
                style: style_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 63dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23.png" /> ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 63dB.shp'
            });
var format_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24 = format_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24.readFeatures(json_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24.addFeatures(features_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24);
var lyr_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24, 
                style: style_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 69dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24.png" /> ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 69dB.shp'
            });
var format_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25 = format_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25.readFeatures(json_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25.addFeatures(features_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25);
var lyr_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25, 
                style: style_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 66dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25.png" /> ACP-C2-1_LAeq_Day_2029 — ACP-C2-1 Day 2029 66dB.shp'
            });
var format_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26 = format_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26.readFeatures(json_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26.addFeatures(features_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26);
var lyr_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26, 
                style: style_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 51dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26.png" /> ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 51dB.shp'
            });
var format_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27 = format_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27.readFeatures(json_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27.addFeatures(features_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27);
var lyr_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27, 
                style: style_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 66dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27.png" /> ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 66dB.shp'
            });
var format_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28 = format_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28.readFeatures(json_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28.addFeatures(features_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28);
var lyr_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28, 
                style: style_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 69dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28.png" /> ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 69dB.shp'
            });
var format_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29 = format_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29.readFeatures(json_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29.addFeatures(features_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29);
var lyr_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29, 
                style: style_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 60dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29.png" /> ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 60dB.shp'
            });
var format_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30 = format_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30.readFeatures(json_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30.addFeatures(features_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30);
var lyr_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30, 
                style: style_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 63dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30.png" /> ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 63dB.shp'
            });
var format_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31 = format_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31.readFeatures(json_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31.addFeatures(features_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31);
var lyr_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31, 
                style: style_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 54dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31.png" /> ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 54dB.shp'
            });
var format_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32 = new ol.format.GeoJSON();
var features_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32 = format_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.readFeatures(json_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.addFeatures(features_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32);
var lyr_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32, 
                style: style_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32,
                popuplayertitle: 'ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 57dB.shp',
                interactive: true,
                title: '<img src="styles/legend/ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.png" /> ACP-C2-1_LAeq_Day_2038 — ACP-C2-1 Day 2038 57dB.shp'
            });
var group_CoreOptionDay2038LAeq = new ol.layer.Group({
                                layers: [lyr_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26,lyr_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27,lyr_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28,lyr_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29,lyr_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30,lyr_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31,lyr_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32,],
                                fold: 'close',
                                title: 'Core Option Day 2038 (LAeq)'});
var group_CoreOptionDay2029LAeq = new ol.layer.Group({
                                layers: [lyr_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19,lyr_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20,lyr_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21,lyr_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22,lyr_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23,lyr_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24,lyr_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25,],
                                fold: 'close',
                                title: 'Core Option Day 2029 (LAeq)'});
var group_FAF2OptionDay2029LAeq = new ol.layer.Group({
                                layers: [lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12,lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13,lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14,lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15,lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16,lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17,lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18,],
                                fold: 'close',
                                title: 'FAF2 Option Day 2029 (LAeq)'});
var group_FAF2OptionDay2038LAeq = new ol.layer.Group({
                                layers: [lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5,lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6,lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7,lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8,lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9,lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10,lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11,],
                                fold: 'close',
                                title: 'FAF2 Option Day 2038 (LAeq)'});

lyr_ESRIGraylight_0.setVisible(true);lyr_Openstreetmaptracks_1.setVisible(true);lyr_OSMStandard_2.setVisible(true);lyr_GoogleSatellite_3.setVisible(true);lyr_maptiler_4.setVisible(true);lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5.setVisible(true);lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6.setVisible(true);lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7.setVisible(true);lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8.setVisible(true);lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9.setVisible(true);lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10.setVisible(true);lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11.setVisible(true);lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12.setVisible(true);lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13.setVisible(true);lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14.setVisible(true);lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15.setVisible(true);lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16.setVisible(true);lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17.setVisible(true);lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18.setVisible(true);lyr_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19.setVisible(true);lyr_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20.setVisible(true);lyr_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21.setVisible(true);lyr_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22.setVisible(true);lyr_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23.setVisible(true);lyr_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24.setVisible(true);lyr_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25.setVisible(true);lyr_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26.setVisible(true);lyr_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27.setVisible(true);lyr_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28.setVisible(true);lyr_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29.setVisible(true);lyr_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30.setVisible(true);lyr_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31.setVisible(true);lyr_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.setVisible(true);
var layersList = [lyr_ESRIGraylight_0,lyr_Openstreetmaptracks_1,lyr_OSMStandard_2,lyr_GoogleSatellite_3,lyr_maptiler_4,group_FAF2OptionDay2038LAeq,group_FAF2OptionDay2029LAeq,group_CoreOptionDay2029LAeq,group_CoreOptionDay2038LAeq];
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.set('fieldAliases', {'Contour': 'Contour', 'Closed': 'Closed', 'Perc': 'Perc', 'CumPerc': 'CumPerc', 'MetricType': 'MetricType', 'MetricName': 'MetricName', 'Shape_Leng': 'Shape_Leng', 'Shape_Area': 'Shape_Area', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.set('fieldImages', {'Contour': '', 'Closed': '', 'Perc': '', 'CumPerc': '', 'MetricType': '', 'MetricName': '', 'Shape_Leng': '', 'Shape_Area': '', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq60dBshp_5.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq57dBshp_6.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq54dBshp_7.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq69dBshp_8.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq51dBshp_9.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq66dBshp_10.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2038_LAeqACPC31Day2038LAeq63dBshp_11.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq51dBshp_12.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq54dBshp_13.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq57dBshp_14.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq60dBshp_15.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq63dBshp_16.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq66dBshp_17.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC31_Day_2029_LAeqACPC31Day2029LAeq69dBshp_18.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202957dBshp_19.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202951dBshp_20.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202954dBshp_21.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202960dBshp_22.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202963dBshp_23.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202969dBshp_24.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2029ACPC21Day202966dBshp_25.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203851dBshp_26.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203866dBshp_27.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203869dBshp_28.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203860dBshp_29.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203863dBshp_30.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203854dBshp_31.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.set('fieldLabels', {'Contour': 'no label', 'Closed': 'no label', 'Perc': 'no label', 'CumPerc': 'no label', 'MetricType': 'no label', 'MetricName': 'no label', 'Shape_Leng': 'no label', 'Shape_Area': 'no label', });
lyr_ACPC21_LAeq_Day_2038ACPC21Day203857dBshp_32.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});